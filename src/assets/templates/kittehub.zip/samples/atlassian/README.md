# Atlassian Samples

These [AutoKitteh](https://github.com/autokitteh/autokitteh) projects
demonstrate 2-way integration with Atlassian services and APIs.

- Confluence
- [Jira](./jira/)
