# Discord Samples

These [AutoKitteh](https://github.com/autokitteh/autokitteh) projects
demonstrate 2-way integration with [Discord](https://discord.com/).
